"""
Privacy Guard Plugin for OpenClaw

A multi-user privacy isolation framework that provides context-based
knowledge access control, output review, and memory filtering.
"""

from .plugin import PrivacyGuardPlugin, create_plugin

__version__ = "1.0.0"
__all__ = ["PrivacyGuardPlugin", "create_plugin"]
