from setuptools import setup, find_packages

setup(
    name="openclaw-privacy-guard",
    version="1.0.0",
    description="Multi-user privacy isolation framework for OpenClaw",
    author="Luna Team",
    license="MIT",
    packages=find_packages(),
    install_requires=[],
    python_requires=">=3.8",
)
