# Privacy Guard Plugin Package

## Package Contents

### Core Files
- `openclaw.plugin.json` - Plugin manifest
- `__init__.py` - Python plugin implementation
- `index.js` - JavaScript plugin implementation
- `pyproject.toml` - Python package configuration
- `README.md` - Documentation
- `LICENSE` - MIT License
- `install.sh` - Installation script

### Documentation
- `WIKI_CONTENT.md` - Wiki documentation content
- `RESEARCH_SUMMARY.md` - Research summary
- `PACKAGE_INFO.md` - This file

### Development Files
- `tests/` - Test suite (50+ tests)
- `examples/` - Usage examples

## Installation

### From Source
```bash
./install.sh
```

### Manual Installation
1. Copy the plugin directory to OpenClaw plugins folder:
   ```bash
   cp -r . ~/.openclaw/plugins/privacy-guard
   ```

2. Update OpenClaw configuration (`~/.openclaw/openclaw.json`):
   ```json
   {
     "plugins": {
       "load": {
         "paths": ["~/.openclaw/plugins/privacy-guard"]
       },
       "entries": {
         "privacy-guard": {
           "enabled": true,
           "review": {"enabled": true},
           "knowledge_base": {"path": "./privacy/knowledge"},
           "defaults": {"visibility": "private"}
         }
       }
     }
   }
   ```

## Building for Distribution

To create a distributable package:

```bash
# Build Python package
python -m build

# The package will be in dist/ directory:
# - openclaw-privacy-guard-1.0.0.tar.gz
# - openclaw_privacy_guard-1.0.0-py3-none-any.whl
```

## Testing

Run the test suite:

```bash
python3 test_plugin_structure.py
python3 -m pytest tests/ -v
```

## Version Information

- Version: 1.0.0
- OpenClaw Compatibility: >= 2026.2.0
- License: MIT
- Author: Luna Team
- Build Date: Thu Feb 12 05:07:06 UTC 2026

## Support

- Documentation: README.md
- Examples: examples/basic_usage.py
- Tests: tests/test_privacy_guard.py
- Issues: GitHub repository
